<!DOCTYPE html>
<html lang="en">
<?php include_once('functions.php');?>

<head>
  <title> Welcome! </title>
  <link rel="stylesheet" type="text/css" href="stylesheetPHP.css">
  <meta name="author" content="<?php echo $my_name;?>">
  <meta name="software editor" content="<?php echo $webpage_editor;?>">
  <meta name="$web server software" content="<?php echo $web_server_software;?>">
  <!-- <meta http-equiv="refresh" content="10"> -->
</head>

<body>

</body>
