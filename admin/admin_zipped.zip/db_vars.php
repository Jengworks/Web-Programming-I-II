<?php
  $dbUsername = "admin"; // probably 'root'
  $dbPassword = "carves"; // probably ''
  $dbDatabase = "test"; // localhost database name
  $dbServer   = "localhost";
  $pdo = "mysql:host=$dbServer;dbname=$dbDatabase";
?>
